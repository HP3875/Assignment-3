const xlsx = require('xlsx');
const { Inventory, sequelize } = require('../models/Inventory');

async function migrateData() {
    try {
        
        const workbook = xlsx.readFile('inventory.xlsx');
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const data = xlsx.utils.sheet_to_json(sheet);

        
        const cleanedData = data.map(item => ({
            name: item.Name,
            quantity: Math.max(0, parseInt(item.Quantity) || 0), 
            price: parseFloat(item.Price) || 0, 
            description: item.Description
        }));

        
        const uniqueData = Array.from(new Set(cleanedData.map(JSON.stringify))).map(JSON.parse);

        
        await sequelize.sync({ force: true }); 
        await Inventory.bulkCreate(uniqueData);

        console.log('Data migration completed successfully');
        process.exit(0);
    } catch (error) {
        console.error('Migration error:', error);
        process.exit(1);
    }
}

migrateData(); 