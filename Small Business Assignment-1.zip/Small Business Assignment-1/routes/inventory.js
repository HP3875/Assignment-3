const express = require('express');
const router = express.Router();
const { Inventory } = require('../models/Inventory');


router.get('/', async (req, res) => {
    try {
        const items = await Inventory.findAll();
        res.render('index', { items });
    } catch (error) {
        res.status(500).send(error.message);
    }
});


router.get('/add', (req, res) => {
    res.render('add');
});


router.post('/add', async (req, res) => {
    try {
        await Inventory.create(req.body);
        res.redirect('/');
    } catch (error) {
        res.status(400).render('add', { error: error.message });
    }
});


router.get('/edit/:id', async (req, res) => {
    try {
        const item = await Inventory.findByPk(req.params.id);
        res.render('edit', { item });
    } catch (error) {
        res.status(500).send(error.message);
    }
});

router.post('/edit/:id', async (req, res) => {
    try {
        await Inventory.update(req.body, {
            where: { id: req.params.id }
        });
        res.redirect('/');
    } catch (error) {
        res.status(400).send(error.message);
    }
});


router.post('/delete/:id', async (req, res) => {
    try {
        await Inventory.destroy({
            where: { id: req.params.id }
        });
        res.redirect('/');
    } catch (error) {
        res.status(500).send(error.message);
    }
});

module.exports = router; 