Student Name: Harsh Patel
Student ID: 8913372

# Inventory Management System

A web-based inventory management system built with Node.js, Express, and PostgreSQL. This application helps small businesses transition from Excel-based inventory tracking to a more robust and error-free digital solution.

